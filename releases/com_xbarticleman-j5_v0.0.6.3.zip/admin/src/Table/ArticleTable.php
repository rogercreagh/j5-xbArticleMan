<?php
/*******
 * @package xbArticleManager J5
 * @filesource admin/src/Table/ArticleTable.php
 * @version 0.0.4.0 12th January 2024
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2023
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html 
 ******/

namespace Crosborne\Component\Xbarticleman\Administrator\Table;

defined('_JEXEC') or die;

class ArticleTable extends \Joomla\CMS\Table\Content
{
}
